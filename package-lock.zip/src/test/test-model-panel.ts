export class ElementPanel {

}